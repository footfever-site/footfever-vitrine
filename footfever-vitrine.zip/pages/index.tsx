import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function FootFeverVitrine() {
  return (
    <div className="min-h-screen bg-black text-white px-6 py-10 space-y-16">
      {/* Hero Section */}
      <div className="text-center space-y-4">
        <h1 className="text-5xl font-bold text-gold">FootFever</h1>
        <p className="text-xl">Pour ceux qui vivent foot.</p>
        <p className="text-lg text-gray-400">Découvre les maillots qui font vibrer le game.</p>
      </div>

      {/* Maillots Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { name: "Cameroun 2025", img: "/maillots/cameroun.jpg" },
          { name: "France 2025", img: "/maillots/france.jpg" },
          { name: "Mali 2025", img: "/maillots/mali.jpg" },
          { name: "Côte d'Ivoire 2025", img: "/maillots/civ.jpg" },
          { name: "Sénégal 2025", img: "/maillots/senegal.jpg" },
          { name: "PSG Domicile 2023", img: "/maillots/psg.jpg" },
        ].map((maillot) => (
          <Card key={maillot.name} className="bg-gray-900 rounded-2xl overflow-hidden shadow-xl">
            <img src={maillot.img} alt={maillot.name} className="w-full h-64 object-cover" />
            <CardContent className="p-4 text-center">
              <p className="text-lg font-semibold text-gold">{maillot.name}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* About Section */}
      <div className="text-center max-w-2xl mx-auto space-y-4">
        <h2 className="text-3xl font-bold">À propos de FootFever</h2>
        <p className="text-gray-300">
          FootFever, c’est plus qu’un style. C’est une culture. Chaque maillot raconte une histoire,
          chaque tissu est une déclaration. Ici, on vit foot avec style.
        </p>
      </div>

      {/* Contact Section */}
      <div className="text-center space-y-4">
        <h3 className="text-2xl font-bold">Reste connecté</h3>
        <p>Retrouve-nous sur les réseaux :</p>
        <div className="flex justify-center space-x-4">
          <Button variant="outline" className="border-gold text-gold">Instagram</Button>
          <Button variant="outline" className="border-gold text-gold">Snapchat</Button>
        </div>
      </div>
    </div>
  );
}